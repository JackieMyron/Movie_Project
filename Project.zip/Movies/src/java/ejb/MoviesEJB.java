/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.Movies;
import entity.Theaters;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author jaxsm
 */
@Stateless
public class MoviesEJB {

    @PersistenceContext(unitName = "MoviesPU")
    private EntityManager em;

    public void persist(Object object) {
        em.persist(object);
    }

    /**
     * Finds Theaters in the Database by Zipcode
     */
    public List<Theaters> findTheaterByZip(String zip){
        return em.createNamedQuery("Theaters.findByZipcode", Theaters.class)
                .setParameter("zipcode", zip)
                .getResultList();
    }
    
    /**
     * Finds Movies in the Database by Theater
     */
    public List<Movies> findMoviesByTheater(Theaters t){
        return em.createNamedQuery("Movies.findByTheaterID", Movies.class)
                .setParameter("theaterid", t)
                .getResultList();
    }
}
