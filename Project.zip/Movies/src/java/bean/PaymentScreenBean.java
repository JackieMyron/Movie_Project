/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import ejb.MoviesEJB;
import entity.Movies;
import java.io.Serializable;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;

/**
 *
 * @author jaxsm
 */
@Named(value = "paymentScreenBean")
@SessionScoped
public class PaymentScreenBean implements Serializable {

    @EJB
    private MoviesEJB moviesEJB;
    private Movies movie;
    private String creditCard;
    private String message;
    
    /**
     * Creates a New Instance of PaymentScreenBean
     */
    public PaymentScreenBean() {
    }

    /**
     * Getters and Setters 
     */
    public MoviesEJB getMoviesEJB() {
        return moviesEJB;
    }

    public void setMoviesEJB(MoviesEJB moviesEJB) {
        this.moviesEJB = moviesEJB;
    }

    public Movies getMovie() {
        return movie;
    }

    public void setMovie(Movies movie) {
        this.movie = movie;
    }

    public String getCreditCard() {
        return creditCard;
    }

    public void setCreditCard(String creditCard) {
        this.creditCard = creditCard;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    
    /**
     * Navigates to the PaymentScreen.xhtml Page With a Movie 
     */
    public String paymentScreen(Movies movie){
        this.movie = movie;
        return "PaymentScreen";
    }
    
    /**
     * Validates the Length of the Credit Card Number Input
     */
    public void validate(){
       if(creditCard.length() == 16)
            message = "Purchase Successful!";
       else
           message = "Not a Valid Credit Card Number Try Again";
    }
}
