/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import ejb.MoviesEJB;
import entity.Theaters;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;

/**
 *
 * @author jaxsm
 */
@Named(value = "showTheatersBean")
@SessionScoped
public class ShowTheatersBean implements Serializable {

    @EJB
    private MoviesEJB moviesEJB;
    private String zip;
    
    /**
     * Creates a New Instance of ShowTheatersBean
     */
    public ShowTheatersBean() {
    }

    /**
     * Getters and Setters 
     */
    public MoviesEJB getMoviesEJB() {
        return moviesEJB;
    }

    public void setMoviesEJB(MoviesEJB moviesEJB) {
        this.moviesEJB = moviesEJB;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }
    
    /**
     * Navigates to the ShowTheaters.xhtml Page With a Zipcode 
     */
    public String showTheaters(String zip){
        this.zip = zip;
        return "ShowTheaters";
    }
    
    /**
     * Finds the Theaters That Correspond to the Zipcode
     */
    public List<Theaters> TheaterList(){
        return moviesEJB.findTheaterByZip(zip);
    }
}
