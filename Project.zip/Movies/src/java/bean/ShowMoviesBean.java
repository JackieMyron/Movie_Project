/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import ejb.MoviesEJB;
import entity.Movies;
import entity.Theaters;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;

/**
 *
 * @author jaxsm
 */
@Named(value = "showMoviesBean")
@SessionScoped
public class ShowMoviesBean implements Serializable {

    @EJB
    private MoviesEJB moviesEJB;
    private String id;
    private Theaters theater;
    
    /**
     * Creates a New Instance of ShowMoviesBean
     */
    public ShowMoviesBean() {
    }

    /**
     * Getters and Setters 
     */
    public MoviesEJB getMoviesEJB() {
        return moviesEJB;
    }

    public void setMoviesEJB(MoviesEJB moviesEJB) {
        this.moviesEJB = moviesEJB;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Theaters getTheater() {
        return theater;
    }

    public void setTheater(Theaters theater) {
        this.theater = theater;
    }

    /**
     * Navigates to the showMovies.xhtml Page With a Theater
     */
    public String showMovies(Theaters theater){
        this.theater = theater;
        return "showMovies";
    }
    
    /**
     * Finds the Movies That Correspond to the Theater
     */
    public List<Movies> MovieList(){
        return moviesEJB.findMoviesByTheater(theater);
    }
}
